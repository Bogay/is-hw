#define KEYSIZE 16

char *gen_key(unsigned int seed);